﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace profile
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Profile Creator");
            Console.WriteLine("**WIP**"); 
            Console.WriteLine("");

            createProfile(); 

            // app exit function 
            Console.WriteLine("");
            Console.Write("To close this app, press any key. ");
            Console.ReadKey(true);
            Console.WriteLine(""); 

        }
        private static void createProfile()
        {
            // QUESTIONS 
            Console.WriteLine("1. What is your first name?");
            int milSeconds = 1000;
            System.Threading.Thread.Sleep(milSeconds);
            Console.Write("Enter your first name here: ");
            string myFirstName;
            myFirstName = Console.ReadLine();

            Console.WriteLine(" ");
            string myLastName;
            Console.WriteLine("2. What is your last name?");
            int milSeconds2 = 1000;
            System.Threading.Thread.Sleep(milSeconds2);
            Console.Write("Enter your last name here: ");
            myLastName = Console.ReadLine();

            Console.WriteLine(" ");
            string myBirthDate;
            Console.WriteLine("3. When is your birth date?");
            int milSeconds3 = 1000;
            System.Threading.Thread.Sleep(milSeconds3);
            Console.Write("Enter your date of birth here (mm/dd/yy): ");
            myBirthDate = Console.ReadLine();

            Console.WriteLine(" ");
            string myAge;
            Console.WriteLine("4. How old are you?");
            int milSeconds4 = 1000;
            System.Threading.Thread.Sleep(milSeconds4);
            Console.Write("Enter your age here: ");
            myAge = Console.ReadLine();

            Console.WriteLine(" ");
            string mySchoolType;
            Console.WriteLine("5. What type of school do you go to?, Primary, Secondary, Post-Secondary?" +
                "Type 'N/A' if you don't go to either one of them (finished school/college)");
            int milSeconds5 = 1000;
            System.Threading.Thread.Sleep(milSeconds5);
            Console.Write("Enter the type of school you go to here: ");
            mySchoolType = Console.ReadLine();

            Console.WriteLine(" ");
            string myGrade;
            Console.WriteLine("6. What is your current grade?");
            int milSeconds6 = 1000;
            System.Threading.Thread.Sleep(milSeconds6);
            Console.Write("Enter your current grade here, or N/A if in college or finished school.: ");
            myGrade = Console.ReadLine();

            Console.WriteLine(" ");
            string myProgLangs;
            Console.WriteLine("7. What programming languages you know so far or use?");
            int milSeconds7 = 1000;
            System.Threading.Thread.Sleep(milSeconds7);
            Console.Write("Enter all the programming languages you know so far or used, or if you don't know any or don't do programming, type 'N/A': ");
            myProgLangs = Console.ReadLine();

            Console.WriteLine(" ");
            string ProgLangNum;
            Console.WriteLine("8. If you had coding experience, how many programming languages have you used?");
            int milSeconds8 = 1000;
            System.Threading.Thread.Sleep(milSeconds8);
            Console.Write("Enter the # of programming languages you have worked with. " +
                "Say 'N/A' if you have no experience or don't know: ");
            ProgLangNum = Console.ReadLine();

            Console.WriteLine(" ");
            string yearsCoded;
            Console.WriteLine("9. How long have you coded so far?");
            int milSeconds9 = 1000;
            System.Threading.Thread.Sleep(milSeconds9);
            Console.Write("Enter approx. how long you have been doing programming. " +
                "Type 'N/A' if you do not code: ");
            yearsCoded = Console.ReadLine();

            System.Threading.Thread.Sleep(2000);
            Console.WriteLine(" ");
            Console.WriteLine("Hello, " + myFirstName + " " + myLastName + ".");
            System.Threading.Thread.Sleep(2000);
            Console.WriteLine(" ");
            Console.WriteLine("Date of Birth: " + myBirthDate);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Age: " + myAge);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("School type: " + mySchoolType);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Grade: " + myGrade);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Programming Languages known: " + myProgLangs);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Number of programming languages used: " + ProgLangNum);
            System.Threading.Thread.Sleep(500);
            Console.WriteLine("Amount of time doing programming: " + yearsCoded);
            Console.WriteLine("");

            // loads date/time
            var date = DateTime.Now;
            System.Threading.Thread.Sleep(1000);
            Console.WriteLine($"\nProfile created on: {date:d} at {date:t}.");

            Console.ReadLine();
        }
    }
}
